========================================================================
    SMART DIGITAL TEXT SCROLLINGBAR 360 PRO - QUICK START GUIDE
========================================================================

Dear User,
Thank you for using Smart Digital Text ScrollingBar 360 Pro!

1. HOW TO RUN ON WINDOWS 11 & WINDOWS 10 (NO ADMIN REQUIRED):
------------------------------------------------------------------------
- When you first run 'DigitalScrollingBar360Pro.exe' downloaded from the web, 
  Windows Defender SmartScreen may display:
  "Windows protected your PC"
- THIS IS NORMAL for newly downloaded software that is newly published.
- Simply click:
    1. "More info"  (مزید معلومات)
    2. "Run anyway" (پھر بھی چلائیں)
- No administrator or root password is required! It runs completely in user mode.
- Tip: You can also right-click 'DigitalScrollingBar360Pro.exe' -> Properties 
  -> check "Unblock" at the bottom -> click OK.

2. PRE-LOADED NOTIFICATIONS & TESTING FILES:
------------------------------------------------------------------------
We have packaged 3 ready-to-use live notification files with this software:
  a) 'English Notifications (US, UK, Canada, Australia).txt'  (Active by Default!)
  b) 'Corporate Notes.txt'
  c) 'Home & Lifestyle.txt'

- When you start the software, 'English Notifications' is automatically active 
  and scrolling across the screen.
- To switch to another file or your own text:
  * Right-click anywhere on the ticker bar -> Select "Load Text File"
  * Choose 'Corporate Notes.txt' or 'Home & Lifestyle.txt'
  * Any edits you make to the active text file in Notepad will AUTO-RELOAD 
    and update live on the ticker!

3. HOW TO RUN ON MACBOOKS (macOS) WITHOUT ROOT:
------------------------------------------------------------------------
- macOS cannot run Windows .exe files natively.
- To run on any Mac (Intel or M1/M2/M3/M4 Apple Silicon) without root privileges:
  1. Open Terminal or double-click 'run_mac.command'.
  2. Or simply run:
     python3 SuperSmartTextTickerPro.py
- Ensure Python 3 with Tkinter is installed on your Mac.

4. COMMERCIAL ACTIVATION & SUPPORT:
------------------------------------------------------------------------
- Web: https://ticker.consultways.com
- Instant Pro Checkout: https://buy.polar.sh/polar_cl_mZJBJUvHSCO3aZ3GjZsW67l59ZCgYK7SDTCgS3vYlPd
- Support: support@consultways.com
========================================================================
