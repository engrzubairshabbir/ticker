#!/bin/bash
cd "$(dirname "$0")"
echo "Starting Smart Digital Text ScrollingBar 360 Pro..."
python3 SuperSmartTextTickerPro.py
